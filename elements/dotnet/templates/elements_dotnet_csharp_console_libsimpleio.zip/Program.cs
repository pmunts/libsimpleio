var log = new IO.Objects.SimpleIO.syslog.Logger();
log.Note("Hello, World!");

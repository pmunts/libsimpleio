print("Remote I/O Protocol Client")

var remdev = IO.Objects.RemoteIO.Device()

print(remdev.Version)
print(remdev.Capabilities)

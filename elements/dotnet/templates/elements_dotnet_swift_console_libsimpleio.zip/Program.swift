var log : IO.Objects.SimpleIO.syslog.Logger =
  new IO.Objects.SimpleIO.syslog.Logger()

log.Note("Hello, World!")

package $safeprojectname$;

public class Program
{
  public static int Main(String []args)
  {
    Console.WriteLine("Hello, World!");
    return 0;
  }
}

using System;

namespace $safeprojectname$
{
	static class Program
	{
		public static Int32 Main(string[] args)
		{
			Console.WriteLine("Hello, world!");
			return 0;
		}
	}
}
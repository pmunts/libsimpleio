﻿print("Hello, World!")

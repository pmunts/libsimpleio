using static System.Console;

WriteLine("\nHello, World!\n");

var log = new IO.Objects.libsimpleio.syslog.Logger("HelloWorld");

log.Note("Hello, World!");

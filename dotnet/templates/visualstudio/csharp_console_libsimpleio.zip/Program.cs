using static System.Console;

WriteLine("Hello World!");

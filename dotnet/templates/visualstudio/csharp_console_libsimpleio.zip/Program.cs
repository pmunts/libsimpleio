var log = new IO.Objects.libsimpleio.syslog.Logger();
log.Note("Hello, World!");
